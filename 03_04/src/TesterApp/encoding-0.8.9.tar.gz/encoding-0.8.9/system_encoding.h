#ifndef __SYSTEM_ENCODING__
#define __SYSTEM_ENCODING__

#include <langinfo.h>
#include <locale.h>

char* get_system_encoding();

#endif
